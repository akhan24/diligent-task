
<!DOCTYPE html>
<html lang="en" >
<head>
    <title>Dynamic Form</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" integrity="sha512-jnSuA4Ss2PkkikSOLtYs8BlYIeeIK1h99ty4YfvRPAlzr377vr3CXDb7sb7eEEBYjDtcYj+AjBH3FLv5uSJuXg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .item.selected{background:#e4fff3;}
        .item.error{background:#ffe4e4;}
    </style>

</head>
<body>


<div class="container">
    <div class="form-create">
        <div class="text-center">
            <h1>Dynaimc Form</h1>
            <p>Fill out fields and check mark all those field to populate</p>
        </div>
        <div class="item p-2">
            <div class="row">
                <div class="col-auto"><input type="checkbox" class="form-check-input"></div>
                <div class="col-auto">
                    <select class="type form-control">
                        <option value="text">Text</option>
                        <option value="email">Email</option>
                        <option value="select">Select</option>
                        <option value="textarea">Textarea</option>
                    </select>
                </div>
                <div class="col-4"><input type="text" placeholder="Title" class="form-control w-100 title"></div>
                <div class="col"><input type="text" placeholder="Options (comma seperated)" class="form-control w-100 options"></div>
            </div>
        </div>
        <div class="btnDv mt-5 d-flex justify-content-end">
            <button type="button" class="btn btn-secondary add-field me-2">Add Field</button>
            <button type="button" class="btn btn-primary generate-form">Generate Form</button>
        </div>
    </div>
    <div class="form-submition d-none">
        <div class="text-center">
            <h1>Form Submition</h1>
            <p>Fill out form and submit</p>
        </div>
        <div class="formDv">
            <?php /* ?>
            <form action="" method="post">
                <div class="fieldDv mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" placeholder="My name" name="" required>
                </div>
                <div class="fieldDv mb-3">
                    <label class="form-label">Email address</label>
                    <input type="email" class="form-control" placeholder="name@example.com" name="" required>
                </div>
                <div class="fieldDv mb-3">
                    <label class="form-label">Name</label>
                    <select class="form-control" name="" required>
                        <option value="text">Text</option>
                        <option value="email">Email</option>
                        <option value="checkbox">Checkbox</option>
                        <option value="select">Select</option>
                        <option value="textarea">Textarea</option>
                    </select>
                </div>
                <div class="fieldDv mb-3">
                    <label class="form-label">Message</label>
                    <textarea class="form-control" name="" required></textarea>
                </div>

                <div class="mt-5 d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary submit-form">Submit Form</button>
                </div>
            </form>
            <?php */ ?>
        </div>
    </div>

</div>






<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js" integrity="sha512-7Pi/otdlbbCR+LnW+F7PwFcSDJOuUJB3OxtEHbg4vSMvzvJjde4Po1v4BR9Gdc9aXNUNFVUY+SK51wWT8WF0Gg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script defer>
   $(function(){

        $('.generate-form').on('click', function(){
            //prepare data
            var fieldData = [], err = false;
            $('.form-create .item').each(function(){
                $(this).removeClass('error selected');
                if($(this).find('input:checkbox').is(':checked')){
                    if($(this).find('.title').val() == ''){
                        $(this).addClass('error');
                        err = true;
                    }else if($(this).find('select.type').val() == 'select' && $(this).find('.options').val() == ""){
                        $(this).addClass('error');
                        err = true;
                    }else{
                        $(this).addClass('selected');
                        var itm = {
                            "type": $(this).find('select.type').val(),
                            "name": slugify($(this).find('.title').val()),
                            "label": $(this).find('.title').val()
                        };
                        if($(this).find('select.type').val() == 'select'){
                            itm["options"] = $(this).find('.options').val().split(',');
                        }
                        fieldData.push(itm);
                    }
                }
            });
            if(!err){getForm(fieldData);}
        });

        $('.formDv').on('submit', 'form', function(e){
            e.preventDefault();
            var hasError = false;
            $(this).find('[name]').each(function(){
                if($(this).is(":invalid")){
                    $(this).addClass('is-invalid');
                    hasError = true;
                }
            });
            if(!hasError){prepareMail();}
        });

        $('.add-field').on('click', function(){
            $('.form-create .btnDv').before('<div class="item p-2"> <div class="row"> <div class="col-auto"><input type="checkbox" class="form-check-input"></div> <div class="col-auto"> <select class="type form-control"> <option value="text">Text</option> <option value="email">Email</option> <option value="select">Select</option> <option value="textarea">Textarea</option> </select> </div> <div class="col-4"><input type="text" placeholder="Title" class="form-control w-100 title"></div> <div class="col"><input type="text" placeholder="Options (comma seperated)" class="form-control w-100 options"></div> </div> </div>');
        })


   });


   function getForm(d){
        //console.log(d);
        var urlajax = "api/",
            data = {
                "form": d
            };
        
        
        jQuery.ajax({
            type: 'post',
            url: urlajax,
            data: data,
            beforeSend: function(response) {
                //$thisbutton.removeClass('added').addClass('loading');
                //$thisbutton.text('Adding...');
            },
            complete: function(response) {
                //$thisbutton.removeClass('loading');
            },
            success: function(response) {
                if (response.error) {
                    //window.location = response.product_url;
                    return;
                } else {
                    //console.log(response);
                    $('.form-create').addClass('d-none');
                    $('.form-submition').removeClass('d-none');
                    $('.form-submition .formDv').html(response.form);
                    //sendMail(response.formItem);
                }
            },
        });
   }

   function sendMail(d){
        //console.log(d);
        var urlajax = "mail/",
            data = {
                "subject": "Diligent Task",
                "message": d,
            };
        
        
        jQuery.ajax({
            type: 'post',
            url: urlajax,
            data: data,
            beforeSend: function(response) {
                //$thisbutton.removeClass('added').addClass('loading');
                //$thisbutton.text('Adding...');
            },
            complete: function(response) {
                //$thisbutton.removeClass('loading');
            },
            success: function(response) {
                if (response.error) {
                    //window.location = response.product_url;
                    return;
                } else {
                    //console.log(response);
                    alert("Mail Sent Successfuly");
                    location.reload();
                }
            },
        });
   }

   function prepareMail(){
        var mailBody = "";
        $('.formDv form .fieldDv').each(function(){
            mailBody = mailBody + "<p>";
            mailBody = mailBody + "<strong>" + $(this).find('label').text() + ": </strong>";

            if($(this).find('input').length > 0)
            mailBody = mailBody + "<span>" + $(this).find('input').val() + "</span>";

            if($(this).find('select').length > 0)
            mailBody = mailBody + "<span>" + $(this).find('select').val() + "</span>";

            if($(this).find('textarea').length > 0)
            mailBody = mailBody + "<span>" + $(this).find('textarea').val() + "</span>";

            mailBody = mailBody + "</p>";
        });
        sendMail(mailBody);
   }


   function slugify(str) {
    return String(str)
        .normalize('NFKD') // split accented characters into their base characters and diacritical marks
        .replace(/[\u0300-\u036f]/g, '') // remove all the accents, which happen to be all in the \u03xx UNICODE block.
        .trim() // trim leading or trailing whitespace
        .toLowerCase() // convert to lowercase
        .replace(/[^a-z0-9 -]/g, '') // remove non-alphanumeric characters
        .replace(/\s+/g, '-') // replace spaces with hyphens
        .replace(/-+/g, '-'); // remove consecutive hyphens
    }
</script>
    
</body>
</html>