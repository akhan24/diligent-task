<?php
class DynamicFormAPI {
    
    public function __construct() {
        // Constructor (can initialize dependencies here)
    }

    /**
     * Method to handle incoming form configuration
     * @param array $data - the form configuration data
     * @return array - the response after processing
     */
    public function handleFormConfig($data) {
        // Check if data is valid (e.g., contains form fields)
        if (empty($data) || !isset($data['form'])) {
            return [
                'status' => 'error',
                'message' => 'No form data provided',
            ];
        }

        // Loop through the form fields and process them
        $formConfig = $data['form'];
        //$formFields = [];


        $formBody = '<form action="" method="post">';

        foreach ($formConfig as $field) {
            if (!isset($field['type']) || !isset($field['name'])) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid form field configuration',
                ];
            }

            // Validate supported field types
            if (!in_array($field['type'], ['text', 'email', 'select', 'textarea'])) {
                return [
                    'status' => 'error',
                    'message' => "Unsupported field type: {$field['type']}",
                ];
            }

            // Add the form field to the response (or save to DB)
            /*$formFields[] = [
                'type' => $field['type'],
                'name' => $field['name'],
                'label' => $field['label'] ?? '',
                'options' => $field['options'] ?? [], // In case of select type
            ];*/
            $formBody .= $this->formHTML($field);
        }


        $formBody .= '<div class="mt-5 d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary submit-form">Submit Form</button>
                </div>
            </form>';

        // Return a success response with the form fields
        return [
            'status' => 'success',
            'message' => 'Form configuration processed successfully',
            //'formItem' => $formFields,
            'form' => $formBody
        ];
    }

    private function formHTML($field){

        if($field['type'] == "text"){
            $fieldHtml = '<div class="fieldDv mb-3">
                        <label class="form-label">'.$field['label'].'</label>
                        <input type="text" class="form-control" name="'.$field['name'].'" required>
                    </div>';
        }

        if($field['type'] == "email"){
            $fieldHtml = '<div class="fieldDv mb-3">
                        <label class="form-label">'.$field['label'].'</label>
                        <input type="email" class="form-control" name="'.$field['name'].'" required>
                    </div>';
        }

        if($field['type'] == "select"){
            $fieldHtml = '<div class="fieldDv mb-3">
                        <label class="form-label">'.$field['label'].'</label>
                        <select class="form-control" name="'.$field['name'].'" required>';
            
            $opt = $field['options'];
            foreach ($opt as $item){
                $fieldHtml .= '<option>'.$item.'</option>';
            }

            $fieldHtml .= '</select>
                    </div>';
        }

        if($field['type'] == "textarea"){
            $fieldHtml = '<div class="fieldDv mb-3">
                        <label class="form-label">'.$field['label'].'</label>
                        <textarea class="form-control" name="'.$field['name'].'" required></textarea>
                    </div>';
        }

        return $fieldHtml;
    }
}
