<?php
// Allow cross-origin access if needed
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Content-Type: application/json');

// Include the FormAPI class
require_once 'api.php';

// Initialize the FormAPI object
$formAPI = new DynamicFormAPI();


// Get the POST data (form configuration)
//$data = json_decode(file_get_contents('php://input'), true);
$data = $_POST;

// Process the form configuration using the FormAPI class
$response = $formAPI->handleFormConfig($data);

// Output the response as JSON
echo json_encode($response);