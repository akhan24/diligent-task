<?php
/**
 * 
 * Block Name: Portfolio
 * 
 */

// create id attribute for specific styling
$id = 'portfolio-'.$block['id'];

// create align class ("alignwide") from block setting ("wide")
$align_class = $block['align'] ? 'align'.$block['align'] : '';

?>

<section id="portfolio <?php echo $id; ?>" class="portfolio section">
    <?php 
        $portfolioTitle = get_field('pf-title');
        $portfolioText  = get_field('pf-text');
        $portfolioCode  = get_field('pf-code');
    ?>
    <div class="container section-title" data-aos="fade-up">
        <?php 
            if(!empty($portfolioTitle)){ 
                echo '<h2>'.$portfolioTitle.'</h2>';
            }
            if(!empty($portfolioText)){ 
                echo '<p>'.$portfolioText.'</p>';
            }
        ?>
    </div>
    <div class="container">
        <?php
            if(!empty($portfolioCode)){ 
                echo $portfolioCode;
            }
        ?>
    </div>
</section>