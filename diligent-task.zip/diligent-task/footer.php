<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package diligent-task
 */

?>


<footer id="footer" class="footer position-relative light-background">

<div class="container footer-top">
  <div class="row gy-4">
	<div class="col-lg-5 col-md-12 footer-about">
		<?php if (is_active_sidebar('footer-widget-01')): dynamic_sidebar('footer-widget-01'); endif; ?>
	  <!-- <a href="index.html" class="logo d-flex align-items-center">
		<span class="sitename">Append</span>
	  </a>
	  <p>Cras fermentum odio eu feugiat lide par naso tierra. Justo eget nada terra videa magna derita valies darta donna mare fermentum iaculis eu non diam phasellus.</p>
	  <div class="social-links d-flex mt-4">
		<a href=""><i class="bi bi-twitter-x"></i></a>
		<a href=""><i class="bi bi-facebook"></i></a>
		<a href=""><i class="bi bi-instagram"></i></a>
		<a href=""><i class="bi bi-linkedin"></i></a>
	  </div> -->
	</div>

	<div class="col-lg-2 col-6 footer-links">
		<?php if (is_active_sidebar('footer-widget-02')): dynamic_sidebar('footer-widget-02'); endif; ?>
	  <!-- <h4>Useful Links</h4>
	  <ul>
		<li><a href="#">Home</a></li>
		<li><a href="#">About us</a></li>
		<li><a href="#">Services</a></li>
		<li><a href="#">Terms of service</a></li>
		<li><a href="#">Privacy policy</a></li>
	  </ul> -->
	</div>

	<div class="col-lg-2 col-6 footer-links">
		<?php if (is_active_sidebar('footer-widget-03')): dynamic_sidebar('footer-widget-03'); endif; ?>   
	  <!-- <h4>Our Services</h4>
	  <ul>
		<li><a href="#">Web Design</a></li>
		<li><a href="#">Web Development</a></li>
		<li><a href="#">Product Management</a></li>
		<li><a href="#">Marketing</a></li>
		<li><a href="#">Graphic Design</a></li>
	  </ul> -->
	</div>

	<div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
		<?php if (is_active_sidebar('footer-widget-04')): dynamic_sidebar('footer-widget-04'); endif; ?> 
	  <!-- <h4>Contact Us</h4>
	  <p>A108 Adam Street</p>
	  <p>New York, NY 535022</p>
	  <p>United States</p>
	  <p class="mt-4"><strong>Phone:</strong> <span>+1 5589 55488 55</span></p>
	  <p><strong>Email:</strong> <span>info@example.com</span></p> -->
	</div>

  </div>
</div>

<div class="container copyright text-center mt-4">
	<?php echo do_shortcode('[copyrights]'); ?>
  <!-- <p>&copy; <span>Copyright</span> <strong class="sitename">Append</strong> <span>All Rights Reserved</span></p> -->
  <div class="credits">
	<!-- All the links in the footer should remain intact. -->
	<!-- You can delete the links only if you've purchased the pro version. -->
	<!-- Licensing information: https://bootstrapmade.com/license/ -->
	<!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
  </div>
</div>

</footer>

<!-- Scroll Top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Preloader -->
<div id="preloader"></div>


<?php /* ?>
	<footer id="colophon" class="site-footer">
		<div class="site-info">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'diligent-task' ) ); ?>">
				<?php
				printf( esc_html__( 'Proudly powered by %s', 'diligent-task' ), 'WordPress' );
				?>
			</a>
			<span class="sep"> | </span>
				<?php
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'diligent-task' ), 'diligent-task', '<a href="http://underscores.me/">Underscores.me</a>' );
				?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->
<?php */ ?>

<?php wp_footer(); ?>

</body>
</html>
